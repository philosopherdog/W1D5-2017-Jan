//
//  Greeter.m
//  Greeter
//
//  Created by steve on 2017-01-13.
//  Copyright © 2017 steve. All rights reserved.
//

#import "Greeter.h"

@implementation Greeter
- (void)greet {
  if ([self.delegate shouldGreet]) {
    NSLog(@"Hello");
    return;
  }
  NSLog(@"I can't say anything, sorry");
}
@end








