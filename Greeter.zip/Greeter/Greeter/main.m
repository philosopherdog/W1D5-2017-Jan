//
//  main.m
//  Greeter
//
//  Created by steve on 2017-01-13.
//  Copyright © 2017 steve. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FriendlyGreetingDecider.h"

int main(int argc, const char * argv[]) {
  Greeter *greeter = [[Greeter alloc] init];
  greeter.delegate = [[FriendlyGreetingDecider alloc] init];
  [greeter greet];
  return 0;
}
