//
//  FriendlyGreetingDecider.m
//  Greeter
//
//  Created by steve on 2017-01-13.
//  Copyright © 2017 steve. All rights reserved.
//

#import "FriendlyGreetingDecider.h"

@implementation FriendlyGreetingDecider
- (BOOL)shouldGreet {
  return YES;
}

- (void)someOtherMethod {
  
}
@end
