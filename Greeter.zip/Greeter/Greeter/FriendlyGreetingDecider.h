//
//  FriendlyGreetingDecider.h
//  Greeter
//
//  Created by steve on 2017-01-13.
//  Copyright © 2017 steve. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Greeter.h"

@interface FriendlyGreetingDecider : NSObject<GreeterDelegate>
- (void)someOtherMethod;

@end
